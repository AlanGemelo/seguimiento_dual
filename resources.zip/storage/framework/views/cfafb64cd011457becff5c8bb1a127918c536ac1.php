<nav class="sidebar sidebar-offcanvas" id="sidebar">
    <ul class="nav">
        <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('dashboard')); ?>">
                <i class="mdi mdi-home menu-icon"></i>
                <span class="menu-title">Dashboard</span>
            </a>
        </li>
        <li class="nav-item nav-category">Opciones</li>
        <li class="nav-item <?php echo e(request()->routeIs('estudiantes.*') ? 'active' : ''); ?>">
            <a class="nav-link" href="<?php echo e(route('estudiantes.index')); ?>">
                <i class="menu-icon mdi mdi-account"></i>
                <span class="menu-title">Estudiantes</span>
            </a>
        </li>
        <?php if(Auth::user()->rol_id === 1): ?>
        <li class="nav-item <?php echo e(request()->routeIs('academicos.*') ? 'active' : ''); ?>">
            <a class="nav-link" href="<?php echo e(route('academicos.index')); ?>">
                <i class="menu-icon mdi mdi-card-text-outline"></i>
                <span class="menu-title">Mentores Academicos</span>
            </a>
        </li>
        <li class="nav-item <?php echo e(request()->routeIs('empresas.*') ? 'active' : '' , request()->routeIs('mentores.*') ? 'active' : ''); ?>">
            <a class="nav-link" data-bs-toggle="collapse" href="#charts" aria-expanded="false"
               aria-controls="charts">
                <i class="menu-icon mdi mdi-home-assistant"></i>
                <span class="menu-title">Empresas</span>
                <i class="menu-arrow"></i>
            </a>
            <div class="collapse" id="charts">
                <ul class="nav flex-column sub-menu">
                    <li class="nav-item <?php echo e(request()->routeIs('empresas.*') ? 'active' : ''); ?>"><a class="nav-link" href="<?php echo e(route('empresas.index')); ?>">Empresa</a>
                    </li>
                    <li class="nav-item <?php echo e(request()->routeIs('mentores.*') ? 'active' : ''); ?>"><a class="nav-link" href="<?php echo e(route('mentores.index')); ?>">Mentor Industrial</a>
                    </li>
                </ul>
            </div>
        </li>
            <li class="nav-item <?php echo e(request()->routeIs('carreras.*') ? 'active' : ''); ?>">
                <a class="nav-link" href="<?php echo e(route('carreras.index')); ?>">
                    <i class="menu-icon mdi mdi-package"></i>
                    <span class="menu-title">Carreras</span>
                </a>
            </li>
            <li class="nav-item <?php echo e(request()->routeIs('estadisticas.*') ? 'active' : ''); ?>">
                <a class="nav-link" href="<?php echo e(route('estadisticas.index')); ?>">
                    <i class="menu-icon mdi mdi-chart-line"></i>
                    <span class="menu-title">Estadisticas</span>
                </a>
            </li>
        <?php endif; ?>
    </ul>
</nav>
<?php /**PATH C:\Users\gemelo\Dual\seguimiento_dual\resources\views/layouts/navbar.blade.php ENDPATH**/ ?>